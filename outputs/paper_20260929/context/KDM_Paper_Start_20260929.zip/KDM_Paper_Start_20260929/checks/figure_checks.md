# Figure inspection — 2026-09-29

Three distinct matplotlib figures were generated from the checked CSV results. Every figure has PNG, PDF, and SVG outputs. The rendering script was successfully executed and all PNG outputs were displayed.

Each final PDF was then rendered at 200 dpi with the provided `render_pdf.py` utility and visually inspected. The bar chart, operating-point plot, and expression matrix have complete titles, labels, tick marks, annotations, and readable numerical values. Text and annotations fit the page bounds. Figure 1 starts the count-derived percentage axis at zero. Figure 2 labels the displayed numerical axis range. Figure 3 includes the complete four-by-four matrix and its percentage scale.

Working PDF renders are stored outside the deliverable directory. Final figures are in `figures/`. Empirical values were read from existing completed results; no synthetic observations were used.
