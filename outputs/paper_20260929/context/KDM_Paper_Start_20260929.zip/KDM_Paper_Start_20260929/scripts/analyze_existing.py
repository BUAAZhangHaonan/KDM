"""Paper-oriented aggregation of the frozen KDM result package (CPU only).

Usage:
    python scripts/analyze_existing.py
    python scripts/analyze_existing.py --original /path/to/KDM_Review
Existing labels and bootstrap intervals are read verbatim. No scoring or inference runs.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CONTEXT = ['model','kind','marker','reference_marker','guided','reference_guided','replicate']
MODELS = ['qwen25vl','qwen35_4b','llava16_mistral','minicpm26','gemma3_4b']
MARKERS = ['UNKNOWN','UNCLEAR','UNSURE','I cannot identify it']
NAMES = {'qwen25vl':'Qwen2.5-VL-7B-Instruct','qwen35_4b':'Qwen3.5-4B',
         'llava16_mistral':'LLaVA-v1.6-Mistral-7B','minicpm26':'MiniCPM-V-2.6',
         'gemma3_4b':'Gemma-3-4B-it'}

def jsonl(path: Path) -> list[dict]:
    with path.open(encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]

def exactly_one(items, description):
    items = list(items)
    if len(items) != 1:
        raise ValueError(f'{description}: expected one record, found {len(items)}')
    return items[0]

def main(original: Path | None = None):
    inputs = ROOT/'inputs'
    d = pd.read_csv(inputs/'condition_metrics.csv')
    d['source_csv_line'] = np.arange(len(d)) + 2
    pairs = jsonl(inputs/'paired_comparisons.jsonl')
    cp = jsonl(inputs/'copy_instruction_pairs.jsonl')
    cm = jsonl(inputs/'copy_condition_metrics.jsonl')
    for i, p in enumerate(pairs, 1): p['source_jsonl_line'] = i
    for i, p in enumerate(cp, 1): p['source_jsonl_line'] = i
    for i, p in enumerate(cm, 1): p['source_jsonl_line'] = i
    assert len(d) == 352 and d['n'].eq(2424).all()
    assert d['n'].sum() == 853248 and len(pairs) == 372 and len(cp) == 40 and len(cm) == 200
    assert not d.duplicated(CONTEXT+['method']).any()
    for a,b,u in [('canonical_correct','canonical_incorrect','canonical_unknown'),
                  ('literal_correct','literal_incorrect','literal_unknown'),
                  ('abstain_true','abstain_false','abstain_unknown')]:
        assert (d[a]+d[b]+d[u]).eq(d['n']).all()
        assert d[u].eq(0).all()
    assert np.allclose(d['canonical_correct']/d['n'], d['canonical_accuracy_lower'])
    assert np.allclose(d['abstain_false']/d['n'], d['coverage'])

    def cond(model, method, marker, kind=None):
        if kind is None:
            kind = 'instruction_preserving' if method.startswith('instruction_') or method=='cda_visual' else 'main'
        sub = d[(d.model==model)&(d.method==method)&(d.marker==marker)&
                (d.reference_marker==marker)&(d.kind==kind)]
        return exactly_one((row for _,row in sub.iterrows()), f'{model}/{method}/{marker}/{kind}')

    def direct_pair(model, method, marker, kind=None):
        if kind is None: kind='instruction_preserving' if method.startswith('instruction_') or method=='cda_visual' else 'main'
        return exactly_one((p for p in pairs if p['comparison']=='same_main_prompt_direct' and
            p['method_a']==method and p['context']['model']==model and p['context']['marker']==marker
            and p['context']['reference_marker']==marker and p['context']['kind']==kind),
            f'direct comparison {model}/{method}/{marker}/{kind}')

    # Every reported paired accuracy point estimate agrees with the condition counts.
    for p in pairs:
        c=p['context']
        a=exactly_one((row for _,row in d.iterrows() if row['method']==p['method_a']
             and all(row[k]==c[k] for k in CONTEXT)), 'pair A')
        b=cond(c['model'], p['method_b'], c['marker'])
        delta=(a['canonical_correct']-b['canonical_correct'])/2424
        assert np.isclose(delta,p['canonical_accuracy_difference_conservative_lower']['estimate'])

    # Complete matched-expression panel, with preservation measured on the Direct-fixed set.
    selected=[]
    for _, row in d[d.marker==d.reference_marker].iterrows():
        model,method,marker,kind=row['model'],row['method'],row['marker'],row['kind']
        base=cond(model,'direct',marker)
        out={k:row[k] for k in CONTEXT+['method','n','source_csv_line']}
        out.update(model_name=NAMES[model],correct=int(row['canonical_correct']),
                   accuracy_pct=100*row['canonical_correct']/row['n'],
                   literal_accuracy_pct=100*row['literal_correct']/row['n'],
                   abstentions=int(row['abstain_true']),coverage_pct=100*row['coverage'],
                   selective_accuracy_pct=100*row['selective_accuracy_lower'],
                   uniform_total_supported_abstentions=int(row['uniform_abstention_tp']),
                   uniform_other_abstentions=int(row['uniform_abstention_fp']))
        if method=='direct':
            out.update(uniform_retained=int(base['uniform_abstention_tp']),
                       uniform_original_supported=int(base['uniform_abstention_tp']),
                       accepted_retained=int(base['abstention_tp']),
                       accepted_original_supported=int(base['abstention_tp']),source_pair_jsonl_line=None)
        else:
            p=direct_pair(model,method,marker,kind)
            u=p['uniform_gt_baseline_reasonable_abstentions_retained_by_a']
            a=p['baseline_reasonable_abstentions_retained_by_a']
            out.update(uniform_retained=u['numerator'],uniform_original_supported=u['denominator'],
                       accepted_retained=a['numerator'],accepted_original_supported=a['denominator'],
                       source_pair_jsonl_line=p['source_jsonl_line'])
        for ref in ['uniform','accepted']:
            den=out[ref+'_original_supported']
            out[ref+'_retention_pct']=100*out[ref+'_retained']/den if den else np.nan
        selected.append(out)
    # Matched copy controls are ordinary deterministic selections of existing complete responses.
    for c in cm:
        if c['kind']!='main' or c['marker']!=c['reference_marker']: continue
        out={k:c[k] for k in CONTEXT}
        out.update(method='copy_'+c['method'],model_name=NAMES[c['model']],n=c['n'],
           correct=c['accuracy_correct_numerator'],accuracy_pct=100*c['accuracy_lower'],
           abstentions=c['abstention_n'],coverage_pct=100*c['coverage'],
           selective_accuracy_pct=100*c['selective_accuracy_lower'],
           source_copy_jsonl_line=c['source_jsonl_line'])
        for ref,prefix in [('uniform','uniform_reference_gt'),('accepted','mixed_reference_gt')]:
            out[ref+'_retained']=c[prefix+'_reasonable_abstention_retained_numerator']
            out[ref+'_original_supported']=c[prefix+'_reasonable_abstention_retained_denominator']
            v=c[prefix+'_reasonable_abstention_retention']
            out[ref+'_retention_pct']=100*v if v is not None else np.nan
        selected.append(out)
    matched=pd.DataFrame(selected)
    matched.to_csv(ROOT/'tables/matched_expression_conditions.csv',index=False)

    # All 40 IP versus original-method pairs; intervals copied from the completed analysis.
    ip=[]
    for p in pairs:
        if p['comparison']!='instruction_vs_base_method': continue
        c=p['context'];acc=p['canonical_accuracy_difference_conservative_lower']
        out={**c,'method_a':p['method_a'],'method_b':p['method_b'],
             'accuracy_delta_pp':100*acc['estimate'],'accuracy_ci_low_pp':100*acc['ci95'][0],
             'accuracy_ci_high_pp':100*acc['ci95'][1], 'source_jsonl_line':p['source_jsonl_line']}
        for ref,k in [('uniform','uniform_gt'),('accepted','reference_gt')]:
            z=p['direct_reasonable_abstention_set_preservation_difference_'+k]
            out[ref+'_retention_delta_pp']=100*z['estimate'] if z['estimate'] is not None else np.nan
            out[ref+'_retention_net_count']=z['numerator']
            out[ref+'_original_supported']=z['denominator']
            ci=z['ci95'] or [None,None]
            out[ref+'_retention_ci_low_pp']=100*ci[0] if ci[0] is not None else np.nan
            out[ref+'_retention_ci_high_pp']=100*ci[1] if ci[1] is not None else np.nan
        for n,k in [('all_input','all_input_correction_retention'),('specific_answer','specific_answer_correction_retention')]:
            v=p[k];out[n+'_corrections_retained']=v['num'];out[n+'_corrections_total']=v['den']
            out[n+'_correction_retention_pct']=100*v['rate'] if v['rate'] is not None else np.nan
        out.update(p['correctness_transitions_a_vs_b'])
        ip.append(out)
    ipdf=pd.DataFrame(ip)
    assert len(ipdf)==40
    ipdf.to_csv(ROOT/'tables/instruction_pairs_all40.csv',index=False)

    # Crossed-expression analysis: hold model, method and main instruction fixed.
    cross=d[(d.kind=='main')&d.method.isin(['vcd','m3id','sid'])].copy()
    cross['abstention_pct']=100*cross['abstain_true']/cross['n']
    cross['accuracy_pct']=100*cross['canonical_correct']/cross['n']
    cross.to_csv(ROOT/'tables/reference_expression_all_cells.csv',index=False)
    wording=[]
    for (model,method,marker),g in cross.groupby(['model','method','marker']):
        assert len(g)==4
        same=g[g.reference_marker==marker].iloc[0]
        other=g[g.reference_marker!=marker]
        wording.append(dict(model=model,method=method,marker=marker,
             same_expression_abstention_pct=float(same.abstention_pct),
             other_three_mean_abstention_pct=float(other.abstention_pct.mean()),
             difference_pp=float(other.abstention_pct.mean()-same.abstention_pct),
             same_source_csv_line=int(same.source_csv_line),
             other_source_csv_lines=';'.join(str(int(x)) for x in other.source_csv_line)))
    word=pd.DataFrame(wording)
    word.to_csv(ROOT/'tables/reference_expression_fixed_main.csv',index=False)
    per=word.groupby(['model','method']).agg(
        main_expressions=('difference_pp','size'),
        mean_difference_pp=('difference_pp','mean'),
        min_difference_pp=('difference_pp','min'),max_difference_pp=('difference_pp','max')).reset_index()
    per.to_csv(ROOT/'tables/reference_expression_model_summary.csv',index=False)

    # Highlighted conditions include every evaluated direct comparator in that slice.
    featured=matched[((matched.model=='llava16_mistral')&(matched.marker=='UNKNOWN'))|
                     ((matched.model=='minicpm26')&(matched.marker=='UNCLEAR'))|
                     ((matched.model=='qwen35_4b')&(matched.marker=='I cannot identify it'))].copy()
    featured.to_csv(ROOT/'tables/featured_conditions_all_methods.csv',index=False)
    fip=ipdf[((ipdf.model=='llava16_mistral')&(ipdf.marker=='UNKNOWN'))|
             ((ipdf.model=='minicpm26')&(ipdf.marker=='UNCLEAR'))|
             ((ipdf.model=='qwen35_4b')&(ipdf.marker=='I cannot identify it'))]
    fip.to_csv(ROOT/'tables/featured_paired_effects.csv',index=False)

    # Validation record concerns only operations actually performed in this session.
    checks={'input_condition_rows':len(d),'aggregate_responses':int(d['n'].sum()),
       'complete_condition_denominators':2424,'all_paired_accuracy_estimates_reconciled':len(pairs),
       'all_conditions_resolved_canonical_literal_abstention':True,
       'instruction_pairs':len(ipdf),'copy_control_conditions':len(cm),
       'copy_instruction_pairs':len(cp),'primary_reference':'existing uniform_reference_gt',
       'uncertainty_source':'existing 2000 category-cluster paired bootstrap intervals',
       'new_inference_calls':0,'new_annotation_calls':0,'new_extraction_calls':0,
       'new_bootstrap_resampling_runs':0,
       'validation_level':'condition-count and completed-paired-result reconciliation',
       'raw_response_level_validation':'requested in the compact export; raw score file resides on server'}
    if original is not None:
        gt=pd.DataFrame(jsonl(original/'outputs/annotations/reference_gt/reference_gt.jsonl'))
        ug=pd.DataFrame(jsonl(original/'outputs/annotations/reference_gt/uniform_reference_gt.jsonl'))
        assert len(ug)==24240 and not ug.duplicated(['model','sample_id']).any()
        assert ug['independent_correct_attempts_lower'].eq(ug['independent_correct_attempts_upper']).all()
        computed=(ug['gold_rank']>1)&(ug['independent_correct_attempts_upper']==0)
        assert computed.eq(ug['gt']).all()
        checks.update(uniform_reference_rows_checked=len(ug),uniform_reference_formula_agreements=int(computed.eq(ug['gt']).sum()))
        merge=gt[['model','sample_id','gt']].merge(ug[['model','sample_id','gt']],on=['model','sample_id'],suffixes=('_accepted','_uniform'),validate='one_to_one')
        sens=merge.groupby('model').apply(lambda x:pd.Series({
            'model_image_pairs':len(x),'accepted_true_uniform_false':int((x.gt_accepted&~x.gt_uniform).sum()),
            'accepted_false_uniform_true':int((~x.gt_accepted&x.gt_uniform).sum()),
            'same_reference_value':int(x.gt_accepted.eq(x.gt_uniform).sum())}),include_groups=False).reset_index()
        sens.to_csv(ROOT/'tables/reference_definition_sensitivity.csv',index=False)
    (ROOT/'checks/analysis_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    # A compact claims file, with explicit source row locations.
    claims=[]
    for model,marker in [('llava16_mistral','UNKNOWN'),('minicpm26','UNCLEAR'),('qwen35_4b','I cannot identify it')]:
        z=ipdf[(ipdf.model==model)&(ipdf.marker==marker)&(ipdf.method_a=='instruction_vcd')].iloc[0]
        for field in ['accuracy_delta_pp','uniform_retention_delta_pp','all_input_correction_retention_pct']:
            claims.append({'claim_id':f'{model}_{marker}_{field}','model':model,'main_expression':marker,
                'metric':field,'value':float(z[field]),'reference':'uniform' if 'retention_delta' in field else 'canonical correctness',
                'source':'outputs/analysis/main_results/paired_comparisons.jsonl',
                'source_line':int(z.source_jsonl_line),'comparison':'instruction_vcd minus vcd'})
    pd.DataFrame(claims).to_csv(ROOT/'tables/claims_index.csv',index=False)
    print(json.dumps(checks,ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original',type=Path,help='Optional original extracted KDM_Review root for reference-row checks')
    main(parser.parse_args().original)
