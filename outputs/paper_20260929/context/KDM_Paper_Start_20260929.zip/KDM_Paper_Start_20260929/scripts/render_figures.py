"""Render three paper-sized figures from the frozen aggregate tables.
Each file contains one plot. Matplotlib's default color cycle/map is used.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
MARKERS=['UNKNOWN','UNCLEAR','UNSURE','I cannot identify it']

def finish(fig, name):
    for ext in ['pdf','png','svg']:
        fig.savefig(ROOT/'figures'/f'{name}.{ext}',dpi=300,bbox_inches='tight',pad_inches=.045)
    plt.close(fig)

def main():
    m=pd.read_csv(ROOT/'tables/featured_conditions_all_methods.csv')
    # 1. Same complete-input accuracy, more original supported abstentions retained.
    z=m[(m.model=='llava16_mistral')&m.method.isin(['vcd','instruction_vcd'])&
        m.kind.isin(['main','instruction_preserving'])].set_index('method').loc[['vcd','instruction_vcd']]
    fig,ax=plt.subplots(figsize=(3.38,2.65),layout='constrained')
    ax.bar([0,1],z.uniform_retention_pct,width=.54)
    for i,(_,r) in enumerate(z.iterrows()):
        ax.text(i,r.uniform_retention_pct+.8,f'{int(r.uniform_retained)} / {int(r.uniform_original_supported)}\n{r.uniform_retention_pct:.2f}%',
                ha='center',va='bottom',fontsize=9)
    ax.set_xticks([0,1],['VCD','IP-VCD'],fontsize=9)
    ax.set_ylim(0,31.5);ax.set_yticks([0,10,20,30]);ax.tick_params(axis='y',labelsize=8)
    ax.set_ylabel('Original supported abstentions retained (%)',fontsize=8.1)
    ax.set_title('LLaVA-v1.6-Mistral-7B · UNKNOWN',fontsize=9,pad=20)
    ax.text(.5,1.035,'Both: 852 / 2,424 correct answers (35.15%)',transform=ax.transAxes,
            ha='center',va='bottom',fontsize=8)
    ax.spines[['top','right']].set_visible(False)
    finish(fig,'fig01_llava_preservation')

    # 2. Four observed operating points, with all methods using the same input set.
    z=m[(m.model=='minicpm26')&m.method.isin(['direct','vcd','instruction_vcd','copy_vcd'])&
        m.kind.isin(['main','instruction_preserving'])].set_index('method')
    labels={'direct':'Direct','vcd':'VCD','instruction_vcd':'IP-VCD','copy_vcd':'Copy original\nabstention'}
    offsets={'direct':(9,-9),'vcd':(-40,-18),'instruction_vcd':(-16,12),'copy_vcd':(-5,-33)}
    shapes={'direct':'o','vcd':'s','instruction_vcd':'D','copy_vcd':'^'}
    fig,ax=plt.subplots(figsize=(3.38,2.78),layout='constrained')
    for k in ['direct','copy_vcd','vcd','instruction_vcd']:
        r=z.loc[k]
        ax.scatter(r.accuracy_pct,r.uniform_retention_pct,marker=shapes[k],s=47)
        ax.annotate(labels[k],(r.accuracy_pct,r.uniform_retention_pct),xytext=offsets[k],
                    textcoords='offset points',fontsize=8,ha='left')
    v=z.loc['vcd'];o=z.loc['instruction_vcd']
    ax.annotate('',xy=(o.accuracy_pct,o.uniform_retention_pct),xytext=(v.accuracy_pct,v.uniform_retention_pct),
                arrowprops={'arrowstyle':'->','lw':1.0,'shrinkA':6,'shrinkB':6})
    ax.text(.48,.70,'IP-VCD vs. VCD\n+1.24 pp accuracy\n+2.67 pp retention',transform=ax.transAxes,fontsize=8,ha='left',va='top')
    ax.set_xlim(28.8,38.9);ax.set_ylim(56,105);ax.set_xticks([30,32,34,36,38]);ax.set_yticks([60,70,80,90,100])
    ax.tick_params(labelsize=8)
    ax.set_xlabel('Correct answers / all 2,424 inputs (%)',fontsize=8.4)
    ax.set_ylabel('Original supported abstentions retained (%)',fontsize=8.1)
    ax.set_title('MiniCPM-V-2.6 · UNCLEAR',fontsize=9,pad=8)
    ax.spines[['top','right']].set_visible(False)
    finish(fig,'fig02_minicpm_operating_points')

    # 3. Reference-expression intervention, holding the main instruction fixed in each row.
    d=pd.read_csv(ROOT/'tables/reference_expression_all_cells.csv')
    z=d[(d.model=='qwen25vl')&(d.method=='vcd')].pivot(index='marker',columns='reference_marker',values='abstention_pct').loc[MARKERS,MARKERS]
    labels=['UNKNOWN','UNCLEAR','UNSURE','I cannot\nidentify it']
    fig,ax=plt.subplots(figsize=(3.60,3.35),layout='constrained')
    im=ax.imshow(z.values,vmin=0,vmax=100,alpha=.38,aspect='equal')
    for i in range(4):
        for j in range(4):
            ax.text(j,i,f'{z.iloc[i,j]:.1f}',ha='center',va='center',fontsize=9,
                    fontweight='bold' if i==j else 'normal')
    ax.set_xticks(range(4),labels,fontsize=7.0);ax.set_yticks(range(4),labels,fontsize=7.3)
    ax.set_xlabel('Abstention expression in the reference prompt',fontsize=8.1,labelpad=5)
    ax.set_ylabel('Expression in the main prompt',fontsize=8.1,labelpad=5)
    ax.set_title('Qwen2.5-VL-7B-Instruct · VCD',fontsize=9,pad=11)
    ax.tick_params(length=0)
    bar=fig.colorbar(im,ax=ax,fraction=.047,pad=.025,ticks=[0,25,50,75,100])
    bar.ax.tick_params(labelsize=7);bar.set_label('Abstention rate (%)',fontsize=8)
    finish(fig,'fig03_reference_expression_matrix')
    print('Saved three figures, each in PDF, PNG and SVG.')

if __name__=='__main__':main()
