"""Render a booktabs table from the checked, frozen aggregate results."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def main():
    frame = pd.read_csv(ROOT / 'tables/featured_conditions_all_methods.csv')
    blocks = [('llava16_mistral', r'LLaVA-v1.6-Mistral-7B / UNKNOWN'),
              ('minicpm26', r'MiniCPM-V-2.6 / UNCLEAR')]
    specs = [
        ('direct', 'main', 'Direct'),
        ('vcd', 'main', 'VCD'),
        ('vcd', 'reference_instruction_removed', 'VCD: unguided reference'),
        ('copy_vcd', 'main', 'Copy original abstention'),
        ('cda_visual', 'instruction_preserving', 'CDA (visual adaptation)'),
        ('instruction_vcd', 'instruction_preserving', r'\textbf{IP-VCD}'),
    ]
    lines = [
        '% Requires booktabs. Values are generated, not manually entered.',
        r'\begin{table*}[t]', r'\centering', r'\small',
        r'\begin{tabular}{lrrrr}', r'\toprule',
        r'Method & Correct / 2,424 & Accuracy (\%) & Coverage (\%) & Original abstentions retained \\',
        r'\midrule',
    ]
    for bi,(model,title) in enumerate(blocks):
        if bi:
            lines.append(r'\midrule')
        lines.append(r'\multicolumn{5}{l}{\textit{'+title+r'}} \\')
        for method,kind,label in specs:
            selected=frame[(frame['model']==model)&(frame['method']==method)&(frame['kind']==kind)]
            if len(selected)!=1:
                raise ValueError(f'Expected one row, found {len(selected)}: {model}/{method}/{kind}')
            row=selected.iloc[0]
            lines.append(f"{label} & {int(row['correct']):,} & {row['accuracy_pct']:.2f} & "
                         f"{row['coverage_pct']:.2f} & {int(row['uniform_retained'])}/{int(row['uniform_original_supported'])} "
                         f"({row['uniform_retention_pct']:.2f}\\%) \\\\")
    lines += [r'\bottomrule',r'\end{tabular}',
        r'\caption{Selected model--instruction conditions on Food-101. Accuracy and coverage use all 2,424 evaluation inputs. Original probe-supported abstentions are fixed by direct abstention, a ground-truth category rank below first place, and zero correct answers in ten independent probes. Their denominators are 287 and 374 for the two blocks. The copy control returns the original direct response on direct abstentions and uses VCD otherwise. IP-VCD uses three conditional streams, compared with two for VCD. Complete methods, instructions, reference definitions, and paired intervals are reported in the appendix.}',
        r'\label{tab:main_selected}',r'\end{table*}',
    ]
    dest=ROOT/'paper/main_table.tex'
    dest.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'Wrote {dest}')

if __name__=='__main__':
    main()
