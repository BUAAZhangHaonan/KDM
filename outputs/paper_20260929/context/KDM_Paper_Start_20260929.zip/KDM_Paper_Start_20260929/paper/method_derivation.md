# Method derivation for the first paper draft

Notation follows `02_英文替换段落.md`. All identities are evaluated at the same model, question, image identity and generated prefix. g,c,r,q_g are log-probability vectors. The support S is fixed for each comparison and has positive guided probabilities. α≥0.

## 1. The instruction–reference interaction

Write δ_c=g−c and δ_r=q_g−r. Then

\[
\begin{aligned}
s^{\mathrm{VCD}}&=(1+\alpha)g-\alpha q_g\\
&=(1+\alpha)c-\alpha r+\delta_c+\alpha(\delta_c-\delta_r),\\
s^{\mathrm{IP}}&=g+\alpha(c-r)\\
&=(1+\alpha)c-\alpha r+\delta_c.
\end{aligned}
\]

Consequently,

\[
s^{\mathrm{IP}}-s^{\mathrm{VCD}}
=\alpha\big[(q_g-r)-(g-c)\big].
\]

The difference expresses how the instruction affects the reference and normal-image conditions differently.

## 2. Preservation of the instruction contribution

For retained candidates i,j, compare the guided construction with the same construction whose base is c. The unguided contrast score is

\[
u=c+\alpha(c-r).
\]

The change in log-odds is

\[
(s^{\mathrm{IP}}_i-s^{\mathrm{IP}}_j)-(u_i-u_j)
=(g_i-g_j)-(c_i-c_j).
\]

Thus, the normal-image instruction effect on pairwise log-odds is retained once on the common support. Normalizers cancel in this pairwise comparison. The evaluated VCD support is defined from g: S={i:exp(g_i)≥β max_j exp(g_j)}, β=0.1.

## 3. Three coefficients

Within the linear score family s=ag+bc+dr, retaining the guided-base increment once sets a=1. Requiring the score to reduce to ordinary VCD when g=c gives b=α and d=−α. The resulting score is g+α(c−r).

This argument identifies the coefficients within the declared linear family. In the paper, the input roles and the resulting behavioral effects carry the methodological contribution. DExperts supplies the related base-plus-expert-difference computational family.

## 4. KL-regularized visual support

On S, let G_i=exp(g_i)/Σ_{j∈S}exp(g_j), and define d_i=c_i−r_i. Consider a distribution π supported on S and the objective

\[
J(\pi)=\alpha\mathbb E_\pi[d]-D_{\mathrm{KL}}(\pi\|G).
\]

Define

\[
Z=\sum_{j\in S}G_j e^{\alpha d_j},\qquad
\pi_i^*=G_i e^{\alpha d_i}/Z.
\]

Substituting logπ_i*=logG_i+αd_i−logZ yields

\[
J(\pi)=\log Z-D_{\mathrm{KL}}(\pi\|\pi^*).
\]

The KL divergence reaches zero at π=π*, giving the unique maximizer. Its unnormalized log-score is g+α(c−r), up to a token-independent constant. The objective rewards the visual log-ratio while anchoring the distribution to the guided model on the retained support.

## 5. Extension to IP-M3ID

The implemented IP-M3ID uses the unguided normal-image maximum probability to select its gate and sets the active weight to expm1(λ(t+offset)). The weight is zero when the gate is inactive. It uses full support. The VCD interaction comparison above uses a common α; the IP-M3ID extension states its actual gate and time-dependent weight explicitly.

## 6. Placement

Main text: three conditions, the interaction equation, and the shared-support instruction identity. Appendix: coefficient derivation, KL objective proof, and the existing grouped-probability/Rényi derivation when referenced by the corresponding analysis. Empirical local probability decompositions are paired with the available shared-prefix records and their actual candidate definitions.
