# KDM 英文替换段落 v0.1

本轮写作依据：9月29日成果包的canonical评分与五模型统一参考。下列英文段落可直接替换 `paper/main.md` 对应位置。方括号引文键对应本包 `paper/references_first_pass.bib`。正式英文采用“original probe-supported abstentions”表达由统一参考定义的原有合理弃权。

## 1. 替换标题

**Preserving Abstention in Visual Contrastive Decoding**

方法名：**Instruction-Preserving Visual Contrastive Decoding (IP-VCD)**。扩展方法名：**IP-M3ID**。

## 2. 整段替换Abstract

Visual contrastive decoding strengthens image-conditioned predictions by contrasting normal and degraded visual inputs. When paired with an abstention instruction, the same operation also changes how a model expresses uncertainty. We investigate this interaction in a five-model Food-101 study with 2,424 evaluation images. Under an UNKNOWN instruction, VCD raises LLaVA-v1.6-Mistral-7B accuracy from 28.42% to 35.15% while replacing 88.5% of its original abstentions supported by independent answer probes and category rankings. Crossed comparisons of four abstention expressions further reveal large behavioral changes from reference wording alone. We derive the instruction–reference interaction in the contrastive score and introduce Instruction-Preserving Visual Contrastive Decoding (IP-VCD). The method adds an unguided visual contrast to a guided base distribution, preserving the instruction contribution at each shared-prefix comparison. On LLaVA under UNKNOWN, IP-VCD nearly doubles the number of retained original probe-supported abstentions at the same observed accuracy. On MiniCPM-V-2.6 under UNCLEAR, it improves accuracy and abstention retention over VCD by 1.24 and 2.67 percentage points, respectively, while retaining 93.8% of VCD’s corrections. These findings connect the behavior of visual references to an actionable decoding design for jointly supporting correct answers and informed abstention.

数字绑定：LLaVA对应UNKNOWN主提示及同表达VCD参考；MiniCPM对应UNCLEAR主提示及同表达VCD参考；93.8%采用全部Direct错误与弃权输入上的VCD纠正集合。摘要中的“nearly doubles”对应33到61。上述范围随结果保留。

## 3. 整段替换Introduction

Visual contrastive decoding modifies a vision-language model’s predictions using a degraded visual reference, with the goal of strengthening image-grounded answers [leng2024vcd]. An abstention instruction complements this goal by allowing the model to express uncertainty when a reliable answer is difficult to obtain. Applying the two together creates a consequential interaction: the reference distribution contains preferences about both the image and the requested response behavior. On our balanced Food-101 evaluation, LLaVA-v1.6-Mistral-7B improves from 689 to 852 correct answers after VCD, yet retains only 33 of 287 original abstentions supported by independent answer probes. The resulting 6.72-point accuracy gain therefore coexists with the replacement of 88.5% of these abstentions. This motivates a concrete question: how can visual contrast retain its corrective value while preserving useful abstention behavior?

The reference prompt provides a direct way to investigate this interaction. We cross four expressions—UNKNOWN, UNCLEAR, UNSURE, and “I cannot identify it”—between the main and reference prompts, holding the image, model, generation settings, and main instruction fixed within each comparison. With an UNKNOWN main instruction, changing the Qwen2.5-VL reference expression from UNKNOWN to UNSURE shifts the abstention rate from 31.72% to 84.86%. This sensitivity connects response wording to the effect of visual contrast. At a shared generation prefix, we express the guided contrast as an unguided visual contrast plus the normal-image instruction contribution and an additional instruction–reference interaction. This decomposition identifies the contribution that the decoding rule should retain.

We introduce Instruction-Preserving Visual Contrastive Decoding (IP-VCD), which anchors generation in the guided normal-image distribution and computes the visual increment from an unguided normal/reference pair. Its three conditions assign distinct roles to abstention guidance and visual contrast. On LLaVA with UNKNOWN, IP-VCD retains 61 of the 287 original probe-supported abstentions, compared with 33 for VCD, while both methods correctly answer 852 of 2,424 inputs. On MiniCPM-V-2.6 with UNCLEAR, IP-VCD improves both accuracy and preservation and retains 212 of the 226 inputs that VCD corrects relative to direct decoding. The complete five-model study covers 352 decoding and prompt conditions, allowing these gains to be interpreted alongside the corresponding reference-removal, original-abstention, and alternative-decoding controls.

### 引言末尾的三项贡献

We make three contributions. First, we characterize how visual contrast replaces original probe-supported abstentions alongside its accuracy gains. Second, we identify the role of reference wording through crossed-prompt comparisons and derive the instruction–reference interaction in the decoding score. Third, we introduce a three-condition instruction-preserving decoder and demonstrate complementary improvements in answer accuracy, abstention preservation, and retention of existing corrections.

## 4. 替换研究设定中的参考与指标定义

We use a fixed, model-specific reference derived from category rankings and independent answers. For each model–image pair, let r denote the rank of the correct category among the 101 candidates and let k denote the number of correct answers among ten independent best-estimate responses. We define the probe-supported reference as G = 1[r > 1 and k = 0]. Original probe-supported abstentions are the inputs on which guided direct decoding abstains and G = 1. Every method’s preservation rate uses this same model-and-prompt-specific input set as its denominator. Overall accuracy uses all 2,424 evaluation inputs. The uniform reference applies this definition across all five models; the historical accepted reference is reported in the supplementary sensitivity analysis.

The primary accuracy score compares the unique canonical category identified in the explicit primary dish name with the image label. Canonical word-boundary matching accommodates descriptions such as cooking or flavor modifiers while retaining the recorded primary and side-dish roles. Complete-name equality is reported as a separate literal sensitivity. We retain the frozen response-level correctness and abstention decisions throughout the analysis.

## 5. 方法核心段落：置于行为发现与参考表达分析之后

### Instruction-preserving visual contrast

At generation step t, we evaluate a frozen model under three conditions with the same response prefix. Let g be the log-probabilities from the normal image with abstention guidance, c those from the normal image with the guidance removed, and r those from the unguided visual reference. IP-VCD forms the score

\[
 s^{\mathrm{IP}}=g+\alpha(c-r).
\]

The guided distribution supplies the response policy, while the difference c−r supplies the visual increment. We retain the candidates whose guided probabilities are at least β times the largest guided probability, with α=1 and β=0.1 in the evaluated VCD configuration. All three conditions follow the same generated prefix and maintain their own decoding caches.

To see how this construction treats instructions, let q_g be the guided reference log-probabilities and define the instruction increments δ_c=g−c and δ_r=q_g−r. The standard guided VCD score satisfies

\[
 s^{\mathrm{VCD}}=(1+\alpha)c-\alpha r+\delta_c+\alpha(\delta_c-\delta_r).
\]

IP-VCD retains δ_c once and computes its visual contrast from the unguided pair. Thus, on the shared retained candidates, the method preserves the normal-image instruction contribution while applying the visual increment. The base-plus-difference computation follows the product-of-experts decoding family [liu2021dexperts]; our construction specifies the input conditions and their roles for the observed abstention interaction.

On a fixed retained support, the normalized IP-VCD distribution also maximizes expected visual log-ratio reward with a KL penalty to the guided base distribution. This view expresses a direct objective: favor visually supported tokens while anchoring the response distribution to the guided model. The closed-form solution and the instruction-preservation identity are derived in the appendix.

## 6. 三段主结果文字

### Preserving abstentions at the same observed accuracy

With LLaVA-v1.6-Mistral-7B and UNKNOWN, IP-VCD increases retained original probe-supported abstentions from 33/287 to 61/287, corresponding to 11.50% and 21.25%. Both methods achieve 852/2,424 correct answers, or 35.15% accuracy. The paired preservation gain is 9.76 percentage points, with a 95% category-cluster bootstrap interval of [5.57, 13.75]. This comparison isolates a useful improvement in the observed answer–abstention balance: more of the model’s original supported abstentions survive the visual contrast at an unchanged aggregate number of correct answers.

### Joint gains with retained corrections

With MiniCPM-V-2.6 and UNCLEAR, IP-VCD improves accuracy from 873/2,424 to 903/2,424, or from 36.01% to 37.25%. Preservation of the fixed original probe-supported set increases from 239/374 to 249/374, or from 63.90% to 66.58%. The paired differences are 1.24 accuracy points [0.54, 1.98] and 2.67 preservation points [0.93, 4.50]. IP-VCD also preserves 212 of the 226 inputs that VCD corrects relative to direct decoding, yielding 93.8% correction retention. These inputs include direct-decoding errors and abstentions. Together, the results show improved preservation alongside retained corrective value.

### Separating visual contrast from the instruction contribution

The two prompt controls clarify the role of the third condition. Removing guidance only from the VCD reference retains a coefficient of 1+α on the guided normal-image score. Under MiniCPM–UNCLEAR, this configuration gives 22.61% accuracy and 40.06% answer coverage; IP-VCD yields 37.25% and 77.85%, respectively. The copy-original-abstention control retains the complete direct response whenever it abstains and otherwise uses VCD. Relative to this control, IP-VCD adds 181 correct answers, an accuracy gain of 7.47 points [5.78, 9.24], while preserving 249/374 original probe-supported abstentions. Reporting accuracy, coverage, and preservation together locates each construction’s observed operating point.

## 7. 参考表达分析段落

For each model and fixed main expression, we compare the abstention rate under a matching reference expression with the mean rate under the other three reference expressions. This difference is positive in all 16 main-expression conditions across Qwen2.5-VL, Qwen3.5, LLaVA, and MiniCPM. Averaged over the four main expressions, the differences are 53.14, 36.48, 35.03, and 27.54 percentage points, respectively. Gemma-3-4B-it, which exhibits near-zero direct abstention in this panel, has a corresponding difference of 0.01 points. The full crossed matrices make the reference-prompt effect visible while keeping the main instruction fixed within each row.

这段报告描述性差值。数据导出后，预先固定“每个模型按四种主表达平均、同表达参考与其他三种参考平均之差”的配对类别区间计算，再补入图注。

## 8. 替换Conclusion的候选段落

Visual contrastive decoding acts on abstention behavior as well as visual predictions. Our controlled prompt comparisons expose the role of the reference instruction, and the score decomposition motivates a three-condition construction that retains the guided base contribution. IP-VCD increases abstention preservation at the same observed accuracy on LLaVA and jointly improves accuracy and preservation on MiniCPM while retaining most of VCD’s corrections. These results provide a concrete decoding design for combining visual correction with informed abstention.

## 9. Limitations的正向范围说明草稿

The study uses five fixed vision-language models and a balanced Food-101 evaluation containing 2,424 images. The operational reference combines a 101-category ranking with ten independent answers per model–image pair, and response correctness follows the specified primary-name convention. The complete model-and-prompt matrix records variation across these settings. IP-VCD evaluates three conditional decoding streams per generated step, compared with two for VCD.

已有耗时记录完成导出后，在本段追加实际成本数值与对应表号。当前方法成本列可直接写“三路条件计算／两路条件计算”。
